package src.frontend;

//The following 3 imports are only for the commented-out code
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import java.util.ArrayList;
import src.poiExtractor.*;
import java.util.Scanner;
import java.lang.*;
/*
 * This is just a "silly" example to show you how to use the src.poiExtractor package.
 * Your code in this package should act as the front-end of the application. 
 * You main() method must be drastically different than this one. 
 */
public class MainVanillaExample {

	public static void main(String[] args) {
		ArrayList<AlbumExtractor> ALLALBUMS = new ArrayList<AlbumExtractor>();
		ArrayList<ContentPageExtractor> ALLPAGES = new ArrayList<>();
		ArrayList<PicturePageExtractor> ALLPHOTOS = new ArrayList<>();
		int answer2=1;
		do{
			System.out.println("What would you like to do: (1) Create Album || (2) Create product Album || (3) Edit Album || (4) exit programm ? : "); //AUTO PREPEI NA MPEI SE EPANALHPSH
			Scanner input = new Scanner(System.in);
			//AlbumExtractor finalalbumExtractor = new AlbumExtractor("hi");
			int answer = input.nextInt();
			if (answer == 1){ //CREATE ALBUM
				System.out.println("Give Album name: \t ");
				String b;
				Scanner input2 = new Scanner(System.in);
				int i;
				b=input2.nextLine();
				AlbumExtractor albumExtractor = new AlbumExtractor(b);
				System.out.println("Do you want to create a Page(1) or leave the album empty(2) ? : ");
				i = input.nextInt();
				if (i == 1){
					int exit=1;
					while (exit !=0){
						System.out.println(" New Page created");
						System.out.println("Do you want to give only Title(1) or Title and add content(2) ? : ");
						int s;
						s=input.nextInt();
						if (s== 1){	
							System.out.println("Give Title: ");
							String l;
							l=input2.nextLine();
							TitlePageExtractor tp = new TitlePageExtractor(l);
							albumExtractor.addSlideExtractor(tp);
							System.out.println("Title given");
							break;
						}else{
							System.out.println("GIVE Title: ");
							String y;
							int j;
							y=input2.nextLine();
							System.out.println("ADD TEXT(1) || TEXT AND PHOTO(2) || PHOTO(3) : ");
							j=input.nextInt();
							if ((j ==1) || (j==2)){
								System.out.println("Write here text: ");
								String q,date,pp;
								q=input2.nextLine();
								ArrayList<String> z =  new ArrayList<String>();
								System.out.println("Write also keywords (to finish press .) : ");
								//Scanner input3 = new Scanner(System.in);
								String test = ".";
								pp=input.next();
								while(!pp.equals(test)){ /////PWS NA DIAVAZEI SUNEXOMENA?
									z.add(pp);
									pp=input.next();
								}
								System.out.println("Give also date: ");
								date=input2.nextLine();
								ContentPageExtractor cp=new ContentPageExtractor(y,q,date,z);
								ALLPAGES.add(cp);
								albumExtractor.addSlideExtractor(cp);
							}
							if ((j==2) || (j==3)){
								System.out.println("Give photo name: ");
								String name;
								name=input2.nextLine();
								System.out.println("Give path: ");
								String path;
								path=input.next();
								PicturePageExtractor pp = new PicturePageExtractor(name,path);
								ALLPHOTOS.add(pp);
								albumExtractor.addSlideExtractor(pp);
							}
							System.out.println("Do you want to add more pages(1) or exit(0) : ");
							exit=input.nextInt();
						}	
					}
				}else{
						BlankPageExtractor bp= new BlankPageExtractor();
						albumExtractor.addSlideExtractor(bp);
				}
				//finalalbumExtractor = albumExtractor;
				//albumExtractor.exportPOISlideShow();
				ALLALBUMS.add(albumExtractor);
			}else if(answer ==2){ //CREATE PRODUCT ALBUM
				System.out.println("Give me key word: ");
				String r2;
				r2=input.next();
				AlbumExtractor newalbum= new AlbumExtractor(r2);
				for(int j=0; j<ALLPAGES.size(); j++){
					if (ALLPAGES.get(j).getkeywords().contains(r2)){ //PROSOXH EDW
						newalbum.addSlideExtractor(ALLPAGES.get(j));
					}	
				}
				for(int i=0; i<ALLPHOTOS.size(); i++){
						if (ALLPHOTOS.get(i).getname().contains(r2)){
							newalbum.addSlideExtractor(ALLPHOTOS.get(i));
						}
				}
				//finalalbumExtractor = newalbum;
				//newalbum.exportPOISlideShow();
				ALLALBUMS.add(newalbum);
			}
			if(answer == 3){ //EDIT ALBUM
				System.out.println("---------- ALL ALBUMS ----------");
				for(int i=0; i<ALLALBUMS.size(); i++){ //MENU
					System.out.println(ALLALBUMS.get(i).getname());
				}
				System.out.println("Which album do you want to edit: ");
				String editname;
				Scanner input51 = new Scanner(System.in);
				editname=input51.nextLine();
				for(int j=0; j<ALLALBUMS.size(); j++){
					Scanner input5 = new Scanner(System.in);
					if (ALLALBUMS.get(j).getname().contains(editname)){
						int numbpages= ALLALBUMS.get(j).getcontentpageextractor().size();
						System.out.println("There are " + numbpages +" Pages. Which one do you want to edit: ");
						int choose;
						choose=input.nextInt();
						System.out.println("What do you want to do >> (1)Edit title || (2)Edit text || (3) Edit date || (4) Edit keywords || (5) Edit photo : ");
						int chooseedit;
						chooseedit=input.nextInt();
						if (chooseedit == 1){
							System.out.println("Give me new Title: ");
							String newname;
							newname=input5.nextLine();
							ALLALBUMS.get(j).getcontentpageextractor().get(choose-1).changetitle(newname);
						}else if (chooseedit ==2){
							System.out.println("Write text: ");
							String newtext;
							newtext = input5.nextLine();
							ALLALBUMS.get(j).getcontentpageextractor().get(choose-1).changetext(newtext);	
						}else if (chooseedit == 3){
							System.out.println("Type new date: ");
							String newdate;
							newdate = input5.nextLine();
							ALLALBUMS.get(j).getcontentpageextractor().get(choose-1).changedate(newdate);	
						}else if (chooseedit == 4){
							System.out.println("Give me new keyword: ");
							ArrayList<String> newkeyword = new ArrayList<String>();
							String newkey = input.next();
							newkeyword.add(newkey);
							ALLALBUMS.get(j).getcontentpageextractor().get(choose-1).changekeyword(newkeyword);	
						}else{
							System.out.println("Give me new name of photo: ");
							String newnamephoto,newnamepath;
							newnamephoto = input5.nextLine();
							System.out.println("Give me new path: ");
							newnamepath = input.next();
							PicturePageExtractor newphoto = new PicturePageExtractor(newnamephoto, newnamepath);
							//ALLALBUMS.get(j).getcontentpageextractor().add(newphoto);
							ALLALBUMS.get(j).addSlideExtractor(newphoto);
						}
						//finalalbumExtractor = ALLALBUMS.get(j);
						//ALLALBUMS.get(j).exportPOISlideShow();
					}
				}
			}
			if(answer == 4){ //EXIT BUTTON
				answer2=0;
			}else{
				Scanner input2 = new Scanner(System.in);
				System.out.println("Continue (1) OR Exit (0) ? : ");
				answer2=input2.nextInt();
			}
		}while(answer2 != 0);
		for(int k=0; k<ALLALBUMS.size(); k++){
			ALLALBUMS.get(k).exportPOISlideShow();
		}			
	}				
}				
	
		
		
		
		//TitlePageExtractor tp = new TitlePageExtractor("This is a title"); //basicA
		//ContentPageExtractor cp = new ContentPageExtractor("a title", "a text"); //Page
		//PicturePageExtractor pp = new PicturePageExtractor("image", "resources/amolad.jpg"); //Picture Page
		//BlankPageExtractor bp = new BlankPageExtractor();

/*
 * If you comment this out, you can try an even simpler example
 * without AlbumExtractor.
 * Remember to uncomment the method underneath main() too.
 *
		XMLSlideShow pptVanilla = new XMLSlideShow(); 
		tp.extractPageToPoi(pptVanilla);		
		cp.extractPageToPoi(pptVanilla);
		pp.extractPageToPoi(pptVanilla);
		bp.extractPageToPoi(pptVanilla);
		saveToFile(pptVanilla, "tryVanilla");
		System.out.println("Done with vanilla example!");
*/		
		//AlbumExtractor albumExtractor = new AlbumExtractor("tryAExtr");
		//albumExtractor.addSlideExtractor(tp);
		//albumExtractor.addSlideExtractor(cp);
		//albumExtractor.addSlideExtractor(pp);
		//albumExtractor.addSlideExtractor(bp);
		//albumExtractor.exportPOISlideShow();
		//System.out.println("Done with AE example!");
		
		



/*
 * Useful only if you uncomment the extremely simple example without the AlbumExtractor
 * 
	private static void saveToFile(XMLSlideShow ppt, String filename) {
	    try {
	    	if(filename.endsWith(".pptx") == false) {
	    		filename += ".pptx";
	    	}
	    	System.out.println("Outputing " + ppt.getSlides().size() + " slides");
	    	FileOutputStream out = new FileOutputStream(filename);
	        ppt.write(out);
			out.close();
		} catch (IOException e) {	
			e.printStackTrace();
		}
	}
*/

