package src.poiExtractor;

public interface IAlbumExtractorToPoi {
	public void addSlideExtractor(IPageExtractorToPoi ipe);
	public void exportPOISlideShow();
}
