package src.poiExtractor;
import java.util.ArrayList;
import org.apache.poi.xslf.usermodel.SlideLayout;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFSlideLayout;
import org.apache.poi.xslf.usermodel.XSLFSlideMaster;
import org.apache.poi.xslf.usermodel.XSLFTextShape;

public class ContentPageExtractor implements IPageExtractorToPoi {

	public ContentPageExtractor(String aTitle, String content, String date, ArrayList<String> keywords) {
		this.keywords=keywords;
		this.date=date;
		title = aTitle;
		slideData = content;
	}
	public ContentPageExtractor(ArrayList<String> keywords){
		this.keywords=keywords;
	}
	public void changekeyword(ArrayList<String> newkeywords){
	}
	public void changetitle(String newtitle){
		title = newtitle;
	}
	public void changedate(String newdate){
		this.date = newdate;
	}
	public void changetext(String newtext){
		slideData = slideData + "\n" + newtext;
	}
	@Override
	public void extractPageToPoi(XMLSlideShow ppt) {
		XSLFSlideMaster defaultMaster = ppt.getSlideMasters().get(0);
    	XSLFSlide slide = null;
		XSLFSlideLayout titleBodyLayout = defaultMaster.getLayout(SlideLayout.TITLE_AND_CONTENT);
		slide = ppt.createSlide(titleBodyLayout);
		XSLFTextShape slideTitle = slide.getPlaceholder(0);
		slideTitle.setText(title);
        XSLFTextShape body = slide.getPlaceholder(1);
        body.clearText();
        body.addNewTextParagraph().addNewTextRun().setText(slideData);
	}
	public ArrayList<String> getkeywords(){
		return keywords;
	}
	public void eqkeywords(ArrayList<AlbumExtractor> listamain){	
		ContentPageExtractor x = new ContentPageExtractor(keywords);
		for(int i=0; i< keywords.size(); i++){
			if (x.getkeywords().contains(keywords.get(i))){
				AlbumExtractor test = new AlbumExtractor(keywords.get(i));
				listamain.add(test);
			}		
		}
	}	
	private String title;
	private String slideData;
	private String date;
	private ArrayList<String> keywords= new ArrayList<String>();
	
}
