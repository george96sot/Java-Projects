package src.poiExtractor;

import org.apache.poi.xslf.usermodel.XMLSlideShow;
import java.util.ArrayList;
public interface IPageExtractorToPoi {
	public void extractPageToPoi (XMLSlideShow ppt);
	public void changetitle(String newtitle);
	public void changetext(String newtext);
	public void changedate(String newdate);
	public void changekeyword(ArrayList<String> newkeywords);
}
