package src.poiExtractor;


import java.util.ArrayList;

import org.apache.poi.xslf.usermodel.XMLSlideShow;

public class BlankPageExtractor implements IPageExtractorToPoi {
	public void changetitle(String newtitle){
		
	}
	public void changetext(String newtext){
		
	}
	public void changedate(String newdate){
		
	}
	public void changekeyword(ArrayList<String> newkeywords){
		
	}
	public BlankPageExtractor() {
		;
	}
	
	@Override
	public void extractPageToPoi(XMLSlideShow ppt) {
		ppt.createSlide();
	}

}