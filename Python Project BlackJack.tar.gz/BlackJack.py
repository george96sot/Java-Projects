#Γιώργος Σωτηρλής, Άγγελος Καραμπεκιος #ΑΜ:2827,AM:2716
numbers=['2','3','4','7','8','9','10','A']
aksia={}
trapoula=[]
suits=['\u2660','\u2661','\u2662','\u2663']
for i in numbers:
    if i!='A':
        deck={i+'\u2660':int(i),i+'\u2661':int(i),i+'\u2662':int(i),i+'\u2663':int(i)}
        aksia.update(deck)
    else:
        deck={i+'\u2660':11,i+'\u2661':11,i+'\u2662':11,i+'\u2663':11}
        aksia.update(deck)
    suits=['\u2660','\u2661','\u2662','\u2663']
    
    for n in numbers:
        for s in suits:
            trapoul = '%s%s' % (n,s)
            trapoula.append(trapoul)

trapoula=trapoula[:32]
import random
def writehistory(lista):
    
    g=open('istoriko.txt','a+')
    for x in lista:
        keno=str(x)
        g.write(keno + '\t')
    g.write('\n')
    
    
    g.close()  


def SchuffleDeck(a):
    random.shuffle(a)
    return a

def dealCard(tr,f):
    f.append(tr[0])
    tr.remove(tr[0])
    return tr,f

def total(hand):
    sum=0
    for i in range(0,len(hand)):
        sum=sum+aksia[hand[i]]
    return sum

def compareHands(a1,a2):
    y=0
    if a1>a2:
        y=1
    if a1==a2 or a2>a1:
        y=-1
    return y

u=0
round='a'
apant2='h'
apant='c'
pot=0
round=0
kerdos=0
ak=0
winner=0
mana=10
teliko=0
paixths=[]
paixths2=[]
go=1
while go==1:
    go=2
    ARXH=input('Start new game(n) or continue previous game(c)?:')
    if ARXH=='n':
        g=open('istoriko.txt','w')
        g.write('')
        g.close()
        while apant=='c':
            apant2='h'
            if u==1:
                ak=1
            SchuffleDeck(trapoula)
            k=0
            sum1=0
            paixths=[]
            paixths2=[]
            sum2=0
            y=0
            round=round+1
            sum1=0
            sum2=0
            while sum1<21 and apant2=='h':
                k=k+1
                print('you got',trapoula[0])
                if k==1: 
                    dealCard(trapoula,paixths)
                    pot=int(input('Place your bet:'))
                    while pot>mana:
                        pot=int(input('Place your bet again:'))
                    print('you got',trapoula[0]) 
                dealCard(trapoula,paixths)
                sum1=total(paixths)
                if (k==4 and sum1<21) or (k==1 and sum1==22):
                    sum1=21
                    if k!=4:
                        print('Your total now is',sum1)
                    print('You Win')    
                    winner='Player'
                    SchuffleDeck(trapoula)
                    mana=mana-pot
                    kerdos=kerdos+2*pot
                    y=1
                if sum!=22 and y!=1:
                    print('Your total now is',sum1)    
                if k==3 and aksia[paixths[0]]==7 and aksia[paixths[1]]==7 and aksia[paixths[2]]==7 and y!=1:
                    print('You Win')
                    print('END OF GAME')
                    winner='Player'
                    apant='x'
                    mana=mana-pot
                    kerdos=kerdos+2*pot
                    y=1
                if sum1>21 and y!=1: 
                    print('You Lose')
                    winner='House'
                    mana=mana+pot
                    kerdos=kerdos-pot
                    y=1
                    print('Back balance now is',mana)
                if sum1==21 and y!=1:
                    print('You Win')
                    winner='Player'
                    mana=mana-pot
                    kerdos=kerdos+2*pot
                    y=1
                    apant='x'
                    if mana>0:
                        print('Bank Balance now is',mana)
                if y!=1:
                    apant2=input('Hit(h) or stand(s)?:')
            if sum1<21 and y!=1 and mana>0:
                while sum2<17:
                    print('House got',trapoula[0])
                    dealCard(trapoula,paixths2)
                    sum2=total(paixths2)
                    print('House total now is',sum2)  
                if sum2<21:
                    teliko=compareHands(sum1,sum2)
                if sum2>21:
                    print('You Win')
                    winner='Player'
                    mana=mana-pot
                    kerdos=kerdos+2*pot
                    print('Bank balance now is',mana)
                if sum2==21:
                    print('You Lost')
                    winner='House'
                    mana=mana+pot
                    kerdos=kerdos-pot
                    print('Bank balance now is',mana)    
                if teliko==-1:
                    print('You lose')
                    winner='House'
                    mana=mana+pot
                    kerdos=kerdos-pot
                    print('Bank balance now is',mana) 
                if teliko==1:
                    print('You win')
                    winner='Player'
                    mana=mana-pot
                    kerdos=kerdos+2*pot
                    if mana>0:
                        print('Bank balance now is',mana)  
            if mana<30 and mana>0 and u==0:
                apant=input('Continue(c), print history(h) or exit game(x)?:')
            if mana>=30:
                if u==0:
                    print('LAST TURN')
                u=1
                apant='c'
            if ak==1:
                print('END OF GAME')
                apant=input('Print history(h) or exit game(x)?:')    
            if mana<=0 and u==0:
                print('Bank balance now is',mana)
                print('END OF GAME')
                apant=input('Print history(h) or exit game(x)?:')
            
            lista=[]
            lista.append(round)
            lista.append(pot)
            lista.append(sum1)
            lista.append(sum2)
            lista.append(winner)
            lista.append(mana)
            writehistory(lista)
            sot=open('istoriko.txt','r')
            sot1=sot.read()
            paixths=[]
            paixths2=[]
            k=0
            y=0
            while apant=='h':
                if mana<30 and mana>0:
                    epik='Round   Pot($)  Player  House   Winner  Bank($)'
                    print (epik)
                    print(sot1)
                    apant=input('Continue(c), print history(h) or exit game(x)?:')
                if apant=='h' and mana<=0:
                    epik='Round   Pot($)  Player  House   Winner  Bank($)'
                    print (epik)
                    print(sot1)
                    apant=input('Print history(h) or exit game(x)?:')
                if apant=='h' and u==1:
                    epik='Round   Pot($)  Player  House   Winner  Bank($)'
                    print (epik)
                    print(sot1)
                    iap.close()
                    sot1.close()
                    apant=input('Print history(h) or exit game(x)?:')
                    
            if apant=='x':
                if mana<=0:
                    print('Player won 10$')
                else:
                    if mana<10 and mana!=0:
                        print('Player won',10-mana,'$')
                    if mana>10:
                        print('Player lost',mana-10,'$')
                    if mana==10:
                        print('Bank money is 10$. Player didnt win any money!')      

    
    if ARXH=='c':
        try:            
            g=open('istroriko.txt')
        except IOError:
            print('There is no previous game. New game starts NOW!')             
            g=open('istoriko.txt','w')
            g.write('')
            g.close()
            while apant=='c':
                apant2='h'
                if u==1:
                    ak=1
                SchuffleDeck(trapoula)
                k=0
                sum1=0
                paixths=[]
                paixths2=[]
                sum2=0
                y=0
                round=round+1
                sum1=0
                sum2=0
                while sum1<21 and apant2=='h':
                    k=k+1
                    print('you got',trapoula[0])
                    if k==1: 
                        dealCard(trapoula,paixths)
                        pot=int(input('Place your bet:'))
                        while pot>mana:
                            pot=int(input('Place your bet again:'))
                        print('you got',trapoula[0]) 
                    dealCard(trapoula,paixths)
                    sum1=total(paixths)
                    if (k==4 and sum1<21) or (k==1 and sum1==22):
                        sum1=21
                        if k!=4:
                            print('Your total now is',sum1)
                        print('You Win')    
                        winner='Player'
                        SchuffleDeck(trapoula)
                        mana=mana-pot
                        kerdos=kerdos+2*pot
                        y=1
                    if sum!=22 and y!=1:
                        print('Your total now is',sum1)    
                    if k==3 and aksia[paixths[0]]==7 and aksia[paixths[1]]==7 and aksia[paixths[2]]==7 and y!=1:
                        print('You Win')
                        print('END OF GAME')
                        winner='Player'
                        apant='x'
                        mana=mana-pot
                        kerdos=kerdos+2*pot
                        y=1
                    if sum1>21 and y!=1: 
                        print('You Lose')
                        winner='House'
                        mana=mana+pot
                        kerdos=kerdos-pot
                        y=1
                        print('Back balance now is',mana)
                    if sum1==21 and y!=1:
                        print('You Win')
                        winner='Player'
                        mana=mana-pot
                        kerdos=kerdos+2*pot
                        y=1
                        apant='x'
                        if mana>0:
                            print('Bank Balance now is',mana)
                    if y!=1:
                        apant2=input('Hit(h) or stand(s)?:')
                if sum1<21 and y!=1 and mana>0:
                    while sum2<17:
                        print('House got',trapoula[0])
                        dealCard(trapoula,paixths2)
                        sum2=total(paixths2)
                        print('House total now is',sum2)  
                    if sum2<21:
                        teliko=compareHands(sum1,sum2)
                    if sum2>21:
                        print('You Win')
                        winner='Player'
                        mana=mana-pot
                        kerdos=kerdos+2*pot
                        print('Bank balance now is',mana)
                    if sum2==21:
                        print('You Lost')
                        winner='House'
                        mana=mana+pot
                        kerdos=kerdos-pot
                        print('Bank balance now is',mana)    
                    if teliko==-1:
                        print('You lose')
                        winner='House'
                        mana=mana+pot
                        kerdos=kerdos-pot
                        print('Bank balance now is',mana) 
                    if teliko==1:
                        print('You win')
                        winner='Player'
                        mana=mana-pot
                        kerdos=kerdos+2*pot
                        if mana>0:
                            print('Bank balance now is',mana)  
                if mana<30 and mana>0 and u==0:
                    apant=input('Continue(c), print history(h) or exit game(x)?:')
                if mana>=30:
                    if u==0:
                        print('LAST TURN')
                    u=1
                    apant='c'
                if ak==1:
                    print('END OF GAME')
                    apant=input('Print history(h) or exit game(x)?:')    
                if mana<=0 and u==0:
                    print('Bank balance now is',mana)
                    print('END OF GAME')
                    apant=input('Print history(h) or exit game(x)?:')
                
                lista=[]
                lista.append(round)
                lista.append(pot)
                lista.append(sum1)
                lista.append(sum2)
                lista.append(winner)
                lista.append(mana)
                writehistory(lista)
                sot=open('istoriko.txt','r')
                sot1=sot.read()
                paixths=[]
                paixths2=[]
                k=0
                y=0
                while apant=='h':
                    if mana<30 and mana>0:
                        epik='Round   Pot($)  Player  House   Winner  Bank($)'
                        print (epik)
                        print(sot1)
                        apant=input('Continue(c), print history(h) or exit game(x)?:')
                    if apant=='h' and mana<=0:
                        epik='Round   Pot($)  Player  House   Winner  Bank($)'
                        print (epik)
                        print(sot1)
                        apant=input('Print history(h) or exit game(x)?:')
                    if apant=='h' and u==1:
                        epik='Round   Pot($)  Player  House   Winner  Bank($)'
                        print (epik)
                        print(sot1)
                        apant=input('Print history(h) or exit game(x)?:')
                        
                if apant=='x':
                    if mana<=0:
                        print('Player won 10$')
                    else:
                        if mana<10 and mana!=0:
                            print('Player won',10-mana,'$')
                        if mana>10:
                            print('Player lost',mana-10,'$')
                        if mana==10:
                            print('Bank money is 10$. Player didnt win any money!')      
